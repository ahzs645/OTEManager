const {chromium}=require('/workspace/ote-review/browser/node_modules/playwright-core');
const JSZip=require('/workspace/OTEManager/node_modules/jszip');
const fs=require('node:fs/promises');
const path=require('node:path');
(async()=>{
 const profile=process.env.OTE_QA_FONT_PROFILE||'portable',out=path.join(__dirname,profile),fixture='/workspace/ote-review/pipeline-integration';
 await fs.mkdir(out,{recursive:true});
 const issue=JSON.parse(await fs.readFile(path.join(fixture,'issue.json'),'utf8'));
 const templates=JSON.parse(await fs.readFile(path.join(fixture,'templates.json'),'utf8'));
 const zip=new JSZip();
 for(const t of templates.templates)for(const s of t.slots)if(s.asset?.startsWith('/')){const target='assets/'+path.basename(s.asset);zip.file(target,await fs.readFile(s.asset));s.asset=target;}
 if(issue.layoutPlan.cover.photoPath.startsWith('/')){const target='assets/'+path.basename(issue.layoutPlan.cover.photoPath);zip.file(target,await fs.readFile(issue.layoutPlan.cover.photoPath));issue.layoutPlan.cover.photoPath=target;}
 zip.file('issue.json',JSON.stringify(issue));zip.file('templates.json',JSON.stringify(templates));
 const bytes=await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE'});await fs.writeFile(path.join(out,'safe-issue-recipe.zip'),bytes);
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:1400,height:1050}}),errors=[],responses=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',async response=>{if(response.url().includes('/api/designcraft/native')&&!response.url().includes('artifact='))responses.push({url:response.url(),status:response.status(),json:await response.json()});});
  await page.goto('http://127.0.0.1:8898/designcraft/index.html');
  const panel=page.locator('section.panel').filter({has:page.getByRole('heading',{name:'Generate editable output'})});
  await page.getByRole('button',{name:'Generate native, PDF and IDML'}).waitFor();
  await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(b=>b.textContent==='Generate native, PDF and IDML'&&!b.disabled));
  await page.locator('#import-issue').setInputFiles({name:'safe-issue-recipe.zip',mimeType:'application/zip',buffer:bytes});
  await page.waitForFunction(()=>document.querySelector('#import-status').textContent.includes('imported'));
  await page.locator('#font-profile').selectOption(profile);
  const planned=await page.evaluate(()=>plannedPages.map(p=>({id:p.id,pageNumber:p.pageNumber,articleIds:p.articleIds})));
  await panel.locator('input[type=checkbox]').check();
  await page.getByRole('button',{name:'Generate native, PDF and IDML'}).click();
  await panel.getByText('Generation passed.',{exact:false}).waitFor({timeout:60000});
  const href=await panel.getByRole('link',{name:'Download manifest',exact:true}).getAttribute('href');
  const manifest=await (await page.request.get('http://127.0.0.1:8898'+href)).json();
  const sourceHref=await panel.getByRole('link',{name:'Download source',exact:true}).getAttribute('href');
  const source=await (await page.request.get('http://127.0.0.1:8898'+sourceHref)).json();
  for(const key of ['bundle','native','pdf','idml']){
   const href=await panel.getByRole('link',{name:'Download '+key,exact:true}).getAttribute('href');
   const r=await page.request.get('http://127.0.0.1:8898'+href);if(!r.ok())throw Error('Artifact unavailable '+key);
   await fs.writeFile(path.join(out,'issue.'+({bundle:'zip',native:'designcraft',pdf:'pdf',idml:'idml'})[key]),await r.body());
  }
  await fs.writeFile(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));
  await panel.scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,'native-ui.png')});
  const final=responses.findLast(r=>r.json.status==='completed');
  const report={passed:!!final&&manifest.preflight.errors===0&&source.articles[0].body===issue.articles[0].body&&manifest.fontProfile===profile&&errors.length===0,transport:'actual Docker production Nitro server/API, unprivileged node user, stock CLI',ui:'production static planner and native-export.js',plannedPages:planned,job:final?.json,fontProfile:manifest.fontProfile,cliVersion:manifest.cliVersion,documentFonts:manifest.documentFontSha256,sourceExact:source.articles[0].body===issue.articles[0].body,articleFlows:manifest.articleFlows,nativeCoverReferences:manifest.nativeCoverReferences,preflight:manifest.preflight,apiResponses:responses.map(r=>({url:r.url,status:r.status,jobStatus:r.json.status})),pageErrors:errors};
  await fs.writeFile(path.join(out,'browser-check.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
  if(!report.passed)throw Error('Native UI proof failed');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

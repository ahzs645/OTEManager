# DesignCraft story continuation and native cover references

Read-only capability research against official DesignCraft CLI 0.4.0 and the already-built current CLI 0.6.0. No engine or application code changed; no builds performed. The repository AGENTS.md was read. Its referenced local plan/ directory is absent in this checkout, so current committed capability documentation and command/source definitions were used.

## Verified results

| Capability | Official 0.4.0 | Current 0.6.0 |
|---|---|---|
| `frame.thread` / `frame.unthread` command | Missing | Missing |
| `file.place` with `autoflow: true` | Works | Works |
| Existing native story threaded through allocated pages | Works | Works |
| Nonconsecutive continuation, page 2 to page 4 | Works | Works |
| Threaded story survives stock IDML export/import | Works | Works |
| Native headline/page cross-reference | Works | Works |
| Reference updates after inserting a page and editing headline | Works | Works |
| Native cross-reference survives stock IDML export/import | Works | Works |

The autoflow proof imported exact source text, added eight pages to its initial page, and produced nine linked frames with zero preflight errors/warnings. Autoflow creates margin-sized frames and inserts pages after the last frame of the story. It can shift planned advertising, page counts and the centre spread; it should not silently operate on a protected fixed issue.

The fixed-page proof creates body frames on planned pages 2 and 4. It then performs a minimal native JSON thread patch: the first story retains all source text, its frame list gains the second frame, the second frame references that story, and its formerly empty story is removed. Both versions print continuing text on the two intended pages, preserve the four-page geometry, retain exact source text and reopen IDML with the same two-frame chain. Both native and IDML-cycle preflight have zero errors/warnings. This proves the document model/compositor support; it is not a production-ready thread implementation.

## Recommended local pipeline

Use the existing stock CLI for native generation and rendering. A local worker can support explicit multi-page continuation without changing DesignCraft itself:

1. Add an explicit article continuation plan: article ID, ordered stable page IDs and ordered body-slot IDs. Ordinary repeated article assignments must remain an error; repetition should require a declared continuation chain. Keep the source article once.
2. Compose the entire CommonMark story into its first body frame. Stage continuation frames as empty frames. Accept overset in these temporary page drafts, then validate the assembled complete issue before permitting final PDF/IDML export.
3. After page placement and ID remapping, locate frames by unique article/page/slot labels and bind one story through the declared frame order. Refuse ambiguous labels, nonempty continuation stories, duplicate frames, cyclic chains and chains touching protected artwork. Preserve frame geometry/options and every non-document ZIP payload.
4. Keep rich paragraph/character formatting and URLs in the first complete story; do not split source text by estimated character capacity. Connecting empty frames does not shift UTF-8 link ranges. Verify the complete source story once, the exact ordered frame chain, embedded asset hashes and final native preflight.
5. Reopen the saved native file before final export. Continue to use the checked URL/parent sidecar when reopening IDML. Verify thread continuity in addition to existing text/assets checks.
6. Derive cover references from the first article page. If selecting a body marker rather than the headline, derive the actual composed anchor page, not merely the first allocated frame: a frame break can leave the first frame empty. Stock `document.inspect` reports total story overset/lines but does not expose each frame's composed byte range.

The simplest first implementation is explicit allocated continuation pages with fixed geometry. Automatic addition/removal of continuation pages needs an extra planning pass, advertising/protection constraints and a booklet/centre-spread recalculation; it should not be treated as a transparent extension of current single-page compilation.

## Native cover references can be dynamic after export

Both versions already expose `anchor.create`, `xref.defineFormat`, `xref.insert`, `xref.list` and `anchor.list`. A cover card can contain an actual native reference to an article headline using the format `<pageNum /> · <fullPara />`. The verified proof changes automatically from `3 · Alpha` to `4 · Alpha` after a native page insertion and to `4 · Updated Alpha` after a headline edit. The PDF prints the updated text, and stock IDML reopening resolves the same reference.

Create references after full issue assembly, when destination story IDs are final. Bind by a uniquely labelled headline story and an anchor ID returned by `anchor.create`; avoid the ambiguous `paragraph: text` search. Label the actual cover text frame, rather than only its background rectangle, so the worker can find it safely.

Do not rely on native preflight to catch missing reference destinations. A separate read-only proof deleted the headline anchor on both engine versions: `xref.list` returned `??`, while `preflight.run` still reported zero errors and warnings. The compiler must validate its expected anchors/reference targets and resolved text after reopening, before permitting final output. Captured evidence is `designcraft-unresolved-cross-reference-preflight.json`.

Anchor creation inserts a zero-width U+E00B marker (three UTF-8 bytes) into the headline. Xref insertion puts U+E00C into the cover story. Place destination anchors in headline stories to keep existing exact article-body checks and URL byte ranges unchanged. An existing preserved headline must already contain a suitable anchor; adding one changes its native story and violates preservation. Reject or explicitly defer dynamic references for protected destinations without anchors.

The stock format uses the native page name and offers no independent cross-reference padding setting. Both versions were separately verified to support `layout.section {page:1, style:"arabicLeadingZero"}` even though CLI help does not enumerate that style: page names become `01`–`04` and the reference becomes `04 · Updated Alpha`. This affects document section numbering, so use it as an explicit setting for a new issue and retain original section settings on a protected base. Captured evidence is `designcraft-page-number-padding.json`. Avoid a literal `0` prefix in the reference format: after moving to page 10 it would print `010`.

Source-body exactness, headline-visible text and generated cover-reference values therefore require separate checks. The existing URL sidecar does not implement these references: stock IDML preserves the anchor/xref structures itself in this synthetic proof. A fresh Adobe InDesign opening remains untested.

## Replacing an editable destination with a structurally protected cover

A second synthetic proof validates a constrained anchor-identity transfer in both engine versions. The protected cover contains an xref to its original headline anchor. The worker deletes the editable original headline frame/story, creates the replacement headline on page 2, and calls stock `anchor.create` in that replacement. It then replaces only the freshly created anchor metadata record's ID/name with the original anchor ID/name. The marker remains at the correctly formatted new headline position. The old destination story must already be absent, and the transferred ID must be globally unique.

Before transfer the original cover reference resolves to `??`; afterward it resolves to `2 · Replacement Alpha`. The cover spread and all its native stories remain exactly equal to the original, including the original xref target ID. Its PDF naturally prints the new generated reference. Native preflight and an IDML cycle both pass without errors/warnings, and the cycle resolves the same replacement title/page. `Document::find_anchor` first checks the story encoded in the anchor ID, then falls back to searching other stories, which makes the transfer work even though the destination now has a different story ID (`crates/doc/src/xref.rs:314`).

This preserves cover structure rather than freezing its rendered text: generated reference text changes by design. Only transfer an anchor for the same stable article identity after validating the replacement frame/story. Refuse ambiguous IDs/names, a still-live old destination, undeclared loss of additional referenced anchors, modification of a protected destination, and any unresolved final xref. Perform replacement and transfer on staged output, then verify unchanged cover objects/stories, exact article source and final preflight before publishing outputs.

The stock `<pageNum />` expansion simply outputs the destination's native page name. Attributes such as `width="2" zeroPad="true"` are ignored; this was verified with a scratch format probe in both versions and is explicit in `crates/doc/src/xref.rs:103`. Do not alter a protected base's global section/page numbering to obtain two-digit cover labels. Explicit numbering settings for a newly created issue can instead use the separately verified `arabicLeadingZero` section style described above.

- [Anchor-transfer proof script](/workspace/ote-review/pipeline-research/prove-anchor-transfer.py).
- [Anchor-transfer results](/workspace/ote-review/pipeline-research/designcraft-anchor-transfer.json).
- Tiny native/PDF/IDML and command logs reside in the adjacent `anchor-transfer-proof-0.4.0` and `anchor-transfer-proof-0.6.0` directories.

## Primary source evidence

- [Current missing manual-threading documentation](/workspace/designcraft/docs/gaps.md:17).
- [Native Document::thread implementation](/workspace/designcraft/crates/doc/src/edit.rs:205).
- [Autoflow inserts pages, allocates margin frames and calls thread](/workspace/designcraft/crates/engine/src/cmd/place_text.rs:127).
- [Composer consumes a chain of frames](/workspace/designcraft/crates/compose/src/lib.rs:3).
- [Native cross-reference commands](/workspace/designcraft/crates/engine/src/cmd/xref.rs:12).
- [Anchor insertion changes story bytes](/workspace/designcraft/crates/engine/src/cmd/xref.rs:104).
- [Anchor-to-page index comes from composition](/workspace/designcraft/crates/compose/src/xref.rs:24).
- [Anchor/xref marker constants](/workspace/designcraft/crates/doc/src/xref.rs:20).
- [Stock document inspection lacks per-frame composition ranges](/workspace/designcraft/crates/engine/src/cmd/inspect.rs:81).
- IDML exporter writes ordered frame predecessor/successor references (`crates/idml/src/export.rs:156`) and anchor/cross-reference structures (`:2010`, `:2110`).

## Reproducible evidence

- [Threading proof script](/workspace/ote-review/pipeline-research/prove-threading.py).
- [Threading results](/workspace/ote-review/pipeline-research/designcraft-threading.json).
- [Cross-reference proof script](/workspace/ote-review/pipeline-research/prove-cross-references.py).
- [Cross-reference results](/workspace/ote-review/pipeline-research/designcraft-cross-references.json).
- Proof native/PDF/IDML files and exact command/result logs reside in `thread-proof-0.4.0`, `thread-proof-0.6.0`, `xref-proof-0.4.0` and `xref-proof-0.6.0` beside this report. Their fonts are local symlinks; copy a font scope beside them before transferring them to another machine.

Total generated proof directories are approximately 340 KiB, excluding symlinked font files. The tests are synthetic, use untransformed rectangular frames and one simple story/reference, and cover one IDML cycle per engine version. They do not establish parity with Adobe composition, broad rich-content thread preservation or production worker readiness.

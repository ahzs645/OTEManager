# Source-backed publishing pipeline research

This is a read-only capability assessment. A published download or a documented API is evidence of availability, not evidence that OTE output works on every operating system or round-trips in Adobe. Source responses and hashes are retained in `primary-source-fetch.json`.

## InDesign's existing approach

Adobe documents [cross references tied to paragraph styles or text anchors](https://helpx.adobe.com/indesign/desktop/indexes-and-references/references-and-bookmarks/insert-cross-references.html), rather than manually typed page numbers. The reference follows destination content as it moves. Its [CrossReferenceSource DOM API](https://developer.adobe.com/indesign/uxp/dom/api/c/cross-reference-source/) exposes `sourceText`, `appliedFormat`, stable object IDs and `update()`. OTE should similarly keep article identity separate from its current page number, derive references from actual placement, and validate unresolved destinations before export.

Adobe documents [threading text frames](https://helpx.adobe.com/indesign/desktop/add-and-manage-text/add-and-import-text/thread-text-frames.html): one story continues through a connected sequence of frames. Breaking a thread makes subsequent text overset; it does not discard text. A continuation should therefore reference one full article body and an explicit frame chain, not duplicate or summarize the body on each page.

Adobe's [Smart Text Reflow](https://helpx.adobe.com/indesign/desktop/add-and-manage-text/add-and-import-text/set-up-smart-text-reflow.html) adds/deletes pages automatically. Options constrain insertion to end of story/section/document, limit it to primary frames, preserve facing spreads and delete genuinely empty pages. With non-parent frames, newly added frames are full-page single-column regardless of the original frame attributes. This is useful for books; blindly enabling it conflicts with a newspaper's fixed cover, reserved ads, center spread and page budget. OTE should prefer explicitly planned continuation slots and stop with overset if those slots are exhausted. Any auto-added pages must be an explicit mode followed by a new cover/reference/center-spread validation.

The [TextPreference DOM API](https://developer.adobe.com/indesign/uxp/dom/api/t/text-preference/) confirms `smartTextReflow`, `addPages`, `limitToMasterTextFrames`, `preserveFacingPageSpreads`, `deleteEmptyPages` and synchronous reflow control. A browser text preview is not the authoritative pagination source.

## DesignCraft releases and transports

The [official GitHub release API](https://api.github.com/repos/storytold/designcraft/releases?per_page=10) currently lists [v0.6.0](https://github.com/storytold/designcraft/releases/tag/v0.6.0) and the pinned [v0.4.0](https://github.com/storytold/designcraft/releases/tag/v0.4.0). Both list macOS universal desktop DMG plus separate CLI ZIP; Windows x64/ARM64/x86 installers and portable ZIPs; Linux x86_64/ARM64 packages and tarballs; FreeBSD tarball; web ZIP; and SHA256SUMS. The existing OTE downloader's Linux-only behavior is a companion limitation, not a limitation of available DesignCraft releases. Exact names, URLs and published SHA256 digests are saved in `designcraft-supported-release-assets.json`. Platform binaries were not downloaded or tested during this research.

Packaging source confirms the CLI is included in the Linux tar tree ([packaging/linux/package.sh](https://github.com/storytold/designcraft/blob/v0.6.0/packaging/linux/package.sh)) and separately packaged on macOS ([packaging/macos/package.sh](https://github.com/storytold/designcraft/blob/v0.6.0/packaging/macos/package.sh)). A platform-aware downloader should select the pinned archive, verify its checksum, extract safely, find the real CLI executable and retain the user-supplied CLI override. macOS/Windows runtime verification remains separate from Linux tests.

[The official control protocol](https://github.com/storytold/designcraft/blob/v0.6.0/docs/control-protocol.md) is JSON lines over a localhost TCP socket started with `--control PORT`. It provides `engine.execute`, `document.inspect`, rendering and open/save/export. It explicitly rejects HTTP request lines; browser `fetch` cannot speak directly to it. A browser-to-running-desktop integration needs a narrow local HTTP helper that translates validated high-level operations, or a native integration, not a direct cross-origin fetch to the TCP port.

[The v0.6 README Web section](https://github.com/storytold/designcraft/blob/v0.6.0/README.md#web) says the web app has no control channel; Open/Place use pickers, Save/Export download files. Embedding the official web ZIP does not itself connect OTE article choices or execute the companion scripts. The browser bridge would require a new documented WASM command surface and tests. The current native worker is a more direct way to remove manual CLI steps while preserving the same verified compiler.

## Native composition constraints

DesignCraft's public [known-gap document](https://github.com/storytold/designcraft/blob/v0.6.0/docs/gaps.md) reports that manual threading and `frame.thread`/`frame.unthread` commands are absent. The core document model and composer support threads; `file.place` supports autoflow that adds pages. Do not assume the presence of a command because the document model supports it. The focused capability report supplies actual v0.4/v0.6 command catalogs and minimal native proofs.

The native engine exposes [anchors and cross-reference commands](https://github.com/storytold/designcraft/blob/v0.6.0/crates/engine/src/cmd/xref.rs): `anchor.create`, `xref.insert`, `xref.list`, `anchor.list`, `xref.defineFormat`; `<pageNum />` is a supported format building block. The read-only capability proof verified these on both stock v0.4 and current v0.6: a cover reference `3 · Alpha` becomes `4 · Alpha` after inserting a native page, then `4 · Updated Alpha` after editing the headline; PDF and a stock IDML reopen retain the updated result with zero preflight errors. The anchor was placed in the headline and the article body stayed exact. Scripts and captured results are `prove-cross-references.py` and `designcraft-cross-references.json`.

Create these references after whole-issue merge so native IDs are final. Prefer stable explicit anchors over ambiguous paragraph text search. They insert internal marker characters (anchor U+E00B, cross-reference U+E00C; three UTF-8 bytes each) and metadata, so source-body comparisons, native merge ID remapping and IDML sidecar checks must understand them before integration. An existing protected headline must not acquire a new anchor during preservation; reuse an existing checked anchor or report a compile-time-only reference. The existing checked source text must remain an independent record. This proof does not establish fresh Adobe round-trip behavior.

## Recommended OTE integration contract

1. Export selected article IDs and selected original media, retaining exact source and display anonymity. Treat saved image preferences explicitly, because they are shared with other export formats.
2. Stage and validate an imported recipe before committing its live state. Preserve custom templates and explicit typography exactly during resume/edit/export.
3. Represent each article once, with an opener page and optional ordered continuation frame destinations. Bound continuation slots; reject cycles, repeated openers, ambiguous placements and intersections with preserved native threads.
4. Let the native engine compose the complete story, then check overset, page identities, every continuation frame and actual opener references. Never treat an article's presence somewhere on a preserved spread as proof of placement on a particular page.
5. Record source image SHA256s and stable page/article IDs in the build manifest. Preserved pages must retain their documented identities and article placements; conflicting cover image/field changes must be refused or clearly reported.
6. Route browser native output to a bounded worker using the same pinned CLI/compiler. Accept a recipe bundle, not arbitrary shell commands or filesystem paths. Package native/PDF/IDML, fonts, source/manifest and interchange metadata together; return a complete draft and actionable preflight on fitting failures.
7. Keep engine/compiler version, explicit font profile and artifact checksums in the result. Do not silently switch versions merely because v0.6 exists; expand the tested version matrix first.
8. Verify generated IDML in Adobe and confirm printer requirements separately. The companion's hyperlink/parent-override sidecar is not consumed by Adobe.

## Evidence files

- `primary-source-fetch.json`: URLs, final redirects, hashes and retained source paths.
- `adobe-cross-references.excerpt.txt`, `adobe-threading.excerpt.txt`, `adobe-smart-text-reflow.excerpt.txt`: readable primary documentation.
- `adobe-dom-cross-reference-source.excerpt.txt`, `adobe-dom-smart-text-reflow.excerpt.txt`: public scripting API documentation.
- `designcraft-releases.json`, `designcraft-supported-release-assets.json`: complete and selected official release metadata.
- `designcraft-readme.md`: pinned v0.6 README snapshot.

No Adobe application bundle was accessed, and no third-party implementation code was copied into the OTE project.

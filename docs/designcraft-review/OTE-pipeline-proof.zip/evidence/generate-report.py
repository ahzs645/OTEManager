from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
repo=Path('/workspace/OTEManager');out=Path('/workspace/ote-review/pipeline-integration')
for name,file in [('OTE','SourceSans3-Regular.ttf'),('OTE-Bold','SourceSans3-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(repo/'public/designcraft/assets/fonts'/file)))
pdfmetrics.registerFontFamily('OTE',normal='OTE',bold='OTE-Bold')
styles=getSampleStyleSheet()
for style in styles.byName.values():style.fontName='OTE';style.fontSize=10;style.leading=14
styles['Title'].fontName='OTE-Bold';styles['Title'].fontSize=22;styles['Title'].leading=26
styles['Heading2'].fontName='OTE-Bold';styles['Heading2'].fontSize=14;styles['Heading2'].leading=18;styles['Heading2'].spaceBefore=12
cell=ParagraphStyle('cell',fontName='OTE',fontSize=8.5,leading=11)
def inline(s):
 s=escape(s)
 return re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',lambda m:'<a href="'+m[2]+'" color="#216148">'+m[1]+'</a>',s)
lines=(repo/'docs/DESIGNCRAFT-INTEGRATION-REVIEW.md').read_text().splitlines();story=[];i=0
while i<len(lines):
 line=lines[i]
 if not line.strip():i+=1;continue
 if line.startswith('# '):story.append(Paragraph(inline(line[2:]),styles['Title']));story.append(Spacer(1,12));i+=1;continue
 if line.startswith('## '):story.append(Paragraph(inline(line[3:]),styles['Heading2']));i+=1;continue
 if line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].startswith('|'):
   parts=[s.strip() for s in lines[i].strip('|').split('|')]
   if not all(re.fullmatch(r'[: -]+',s) for s in parts):rows.append([Paragraph(inline(s),cell) for s in parts])
   i+=1
  widths=[140,355] if len(rows[0])==2 else [105,195,195]
  table=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT');table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dce9de')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#b8c9bd')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));heading=story.pop() if story and isinstance(story[-1],Paragraph) and story[-1].style.name=='Heading2' else None
  story.append(KeepTogether(([heading] if heading else [])+[table]));story.append(Spacer(1,10));continue
 paragraph=[]
 while i<len(lines) and lines[i].strip() and not lines[i].startswith('#') and not lines[i].startswith('|'):
  if paragraph and re.match(r'^\d+\. ',lines[i]):break
  paragraph.append(lines[i]);i+=1
 story.append(Paragraph(inline(' '.join(paragraph)),styles['BodyText']));story.append(Spacer(1,8))
def footer(c,d):
 c.setFont('OTE',8);c.setFillColor(colors.HexColor('#536b61'));c.drawString(42,28,'OTE PIPELINE REVIEW · LOCAL IMPLEMENTATION + CHECKED EVIDENCE');c.drawRightString(553,28,str(d.page))
SimpleDocTemplate(str(out/'OTE-pipeline-review.pdf'),pagesize=(595,842),rightMargin=42,leftMargin=42,topMargin=40,bottomMargin=44,title='OTE pipeline review and integration').build(story,onFirstPage=footer,onLaterPages=footer)
print(out/'OTE-pipeline-review.pdf')

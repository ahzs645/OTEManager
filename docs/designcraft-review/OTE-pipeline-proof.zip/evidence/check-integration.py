#!/usr/bin/env python3
"""Independent three-cycle verification of the compiled continuation proof."""
import collections
import hashlib
import json
from pathlib import Path
import sys
import fitz

sys.path.insert(0, '/workspace/OTEManager/tools/designcraft')
from interchange_metadata import restore_metadata, save_metadata
from markdown_story import compose_source
from native_flow import _read_native, _text_frames
from native_references import verify_cover_references, _run

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'output'
CLI = '/workspace/ote-review/cli/designcraft-0.4.0-linux-x86_64/bin/designcraft-cli'
manifest = json.loads((SOURCE / 'build-manifest.json').read_text())
issue = json.loads((SOURCE / 'source-issue.json').read_text())
expected = compose_source(issue['articles'][0]['body'], issue['articles'][0].get('bodyFormat', 'markdown'))['text']


def asset_hashes(entries):
    # Native IDs and thus asset filenames legitimately change on IDML import.
    return collections.Counter(hashlib.sha256(payload).hexdigest()
                               for info, payload in entries if info.filename.startswith('assets/'))


original_assets = asset_hashes(_read_native(SOURCE / 'issue.designcraft')[1])
idml, metadata = SOURCE / 'issue.idml', SOURCE / 'interchange-metadata.json'
results = []
for number in (1, 2, 3):
    output = ROOT / ('cycle-' + str(number))
    output.mkdir(exist_ok=True)
    fonts = output / 'Document Fonts'
    if not fonts.exists():
        fonts.symlink_to(SOURCE / 'Document Fonts', target_is_directory=True)
    native = output / 'issue.designcraft'
    _run(CLI, output, 'import', [('file.open', {'path': str(idml)}), ('file.saveAs', {'path': str(native)})])
    restored = restore_metadata(native, metadata)
    document, entries = _read_native(native)
    matched = [story for story in document['stories'].values() if story['text'] == expected]
    assert len(matched) == 1
    frames = {frame['item']['id']: frame['pageIndex']+1 for frame in _text_frames(document)}
    chain = [frames[fid] for fid in matched[0]['frames']]
    assert chain == [2, 3]
    assert original_assets == asset_hashes(entries)
    references = verify_cover_references(native, manifest['nativeCoverReferences'], CLI, output / 'references')
    save_metadata(native, output / 'interchange-metadata.json')
    engine = _run(CLI, output, 'export', [('file.open', {'path': str(native)}), ('preflight.run', {'minPpi': 150}),
                 ('file.exportPdf', {'path': str(output / 'issue.pdf'), 'standard': 'x4'}),
                 ('file.exportIdml', {'path': str(output / 'issue.idml')})])
    assert engine[1]['errors'] == 0
    with fitz.open(SOURCE / 'issue.pdf') as original_pdf, fitz.open(output / 'issue.pdf') as cycled_pdf:
        visuals = []
        assert len(original_pdf) == len(cycled_pdf)
        for page_number in range(len(original_pdf)):
            original = original_pdf[page_number].get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False)
            cycled = cycled_pdf[page_number].get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False)
            visuals.append(dict(page=page_number+1, sameSize=(original.width, original.height) == (cycled.width, cycled.height),
                                pixelsIdentical=original.samples == cycled.samples))
    results.append(dict(cycle=number, sourceCharacters=len(expected), sourceBytes=len(expected.encode()), bodyExact=True,
                        bodyFramePages=chain, threadFrames=len(matched[0]['frames']), restoredUrls=restored,
                        nativeReferences=references, assetsExact=True, preflight=engine[1], visuals=visuals))
    idml, metadata = output / 'issue.idml', output / 'interchange-metadata.json'
(ROOT / 'independent-checked-cycles.json').write_text(json.dumps(dict(engine='official0.4.0', cycles=results), indent=2) + '\n')
print(json.dumps(dict(cycles=3, bodyCharacters=len(expected), frames=chain, reference=references['features'][0]['text'],
                     allPreflightErrors=0, assetAndBodyChecks=True,
                     allPixelsIdentical=all(page['pixelsIdentical'] for cycle in results for page in cycle['visuals']))))

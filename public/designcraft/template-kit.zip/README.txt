OTE DesignCraft compiler toolkit

The app's browser composer needs no installation. For offline composition:

1. Export a page or issue recipe from OTEManager. Extract it in a separate folder.
   Each recipe carries its selected source artwork and original issue media.
2. Extract this toolkit and run npm install in its root (Node.js 24).
3. For a whole issue:
   node tools/designcraft/compile.mjs --library /path/to/recipe/templates.json --issue /path/to/recipe/issue.json --output /path/to/output
4. For one page, add --template TEMPLATE_ID --page-number N --articles ID1,ID2.
   A fixed section without articles uses --template TEMPLATE_ID with no --articles.

The committed WebAssembly engine produces editable DesignCraft, PDF and IDML.
--cli /path/to/designcraft-cli selects the native executor. --font-dir DIR
--font-profile original2025 uses private original fonts and reports substitutions.
Full source copy is retained. Preflight blocks final output when copy oversets.
Source template notes distinguish editable text from preserved source artwork.
Supplied historical dates, board members and advertisements stay historical.

Classic recipes can still use the Python scripts at the toolkit root after
pip install -r requirements.txt. Source/house designs use the JavaScript command.
The full historical PDF archive and native example gallery remain in OTEManager;
they are not required to compile exported recipes. Adobe/press approval is separate.

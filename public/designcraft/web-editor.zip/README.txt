DesignCraft web 0.9.0 — vendored browser editor (see editor/OTE-PROVENANCE.json)

Serve the extracted folder from HTTPS or localhost and open editor/index.html.
For example: python3 -m http.server 8000
Then open http://localhost:8000/editor/index.html
Use File → Open / Save / Export in the browser editor.
No desktop DesignCraft or local CLI is required.
Original private OTE fonts are not included; fonts you choose stay on your device.
The wrapper checks every engine piece and the complete engine module against wasm-manifest.json.
Licences and provenance are in editor/.
